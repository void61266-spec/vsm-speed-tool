# VSM Speed Tool (Android)

Volta VSM (2026) kontrol ünitesini incelemek için **salt okunur teşhis** uygulaması. Kotlin + Jetpack Compose + Android USB Host API.

> **Durum: derlenmedi ve cihazda test edilmedi.** Kod bu ortamda derlenemedi. İlk derlemede küçük hatalar çıkabilir; çıkarsa GitHub Actions günlüğünü gönderin, düzeltilir.

## Ne yapar

- USB Host API ile bağlı USB cihazlarını listeler (VID/PID, üretici, ürün, arayüzler, uç noktalar).
- Android USB erişim iznini standart yoldan ister; cihaz çıkarılınca bağlantıyı kapatır.
- İzin verilen cihazda **salt okunur** bağlantı açıp ham tanımlayıcı boyutunu ve aygıt tanımlayıcısını okur. Arayüz talep etmez, kontrol/bulk transferi yapmaz.
- Bağlantı testi: sonuçlar gerçek duruma dayanır; yapılmayan adım "Test edilmedi", doğrulanamayan adım "Doğrulanamadı" görünür.
- Firmware dosyalarını yerel depolamaya alır; ad, boyut, SHA-256 ve dosya kabı türünü (Intel HEX, ELF vb.) gösterir.
- Günlük, USB olayları, hata sayacı ve JSON tanı dışa aktarımı (hassas alanlar önceden gösterilir, seri no varsayılan olarak gizli).

## Ne yapmaz

- Kontrol ünitesine komut, veri veya firmware göndermez. Protokol, işlemci ve bootloader bilinmiyor; tahmin edilmez.
- Gerçek hız verisi uydurmaz. Gösterge 0 gösterir; ayarlardan açılan simülasyon SİMÜLASYON etiketi taşır.
- Firmware yazma modülü yoktur. `WriteGate`, doğrulanmış profil, protokol, yedekleme ve biçim koşulları olmadan kapalı kalır.
- İnternet izni yoktur, `allowBackup=false`. Veriler cihazdan çıkmaz.

## Proje yapısı

```
app/src/main/java/tr/vsm/speedtool/
  data/         AppLog, AppPrefs
  usb/          UsbHostManager (USB Host + izin + yaşam döngüsü), UsbModels
  protocol/     DeviceProtocol, HardwareProfile, ProtocolRegistry, WriteGate
  firmware/     FirmwareRepository, FirmwareFormatDetector
  diagnostics/  ConnectionTester
  export/       DiagnosticExport
  ui/           MainViewModel, VsmApp, Components, screens/*
.github/workflows/build-apk.yml   APK derleme (GitHub Actions)
```

## Telefondan APK üretme (bilgisayarsız)

GitHub Actions bulutta derler; telefonda yalnızca dosyaları yüklemeniz yeterli.

1. github.com'da ücretsiz hesap açın, **özel (private)** yeni bir depo oluşturun.
2. Bu ZIP'in içeriğini depoya koyun. Telefonda en pratik yol **Termux** (F-Droid'den):
   ```
   pkg install git unzip
   unzip VsmSpeedTool.zip
   cd VsmSpeedTool
   git init -b main
   git add -A && git commit -m "ilk sürüm"
   git remote add origin https://github.com/KULLANICI/DEPO.git
   git push -u origin main
   ```
   Parola yerine GitHub'da oluşturduğunuz kişisel erişim belirteci (PAT) kullanılır.
   Alternatif: GitHub Codespaces'i telefon tarayıcısında açıp ZIP'i yükleyin ve aynı komutları orada çalıştırın.
3. Depoda **Actions → APK derle → Run workflow** (push da otomatik başlatır).
4. İş bitince çalıştırma sayfasındaki **Artifacts → VsmSpeedTool-debug-apk** dosyasını indirin, ZIP'ten `app-debug.apk` çıkarın.
5. APK'yı açın; Android "bilinmeyen kaynaklardan yükleme" izni isteyecektir.

Derleme hatası olursa Actions günlüğündeki kırmızı kısmı kopyalayıp gönderin.

## Kullanım

1. OTG adaptörünü takın, **USB** sekmesinde **USB cihazlarını yenile**.
2. Cihazı seçin, **USB izni iste**, sonra **Salt okunur bağlantıyı aç**.
3. **Teşhis** sekmesinde bağlantı testini çalıştırın.

Kontrol ünitesi doğrudan USB cihazı olarak görünmüyorsa (ör. seri/CAN adaptörü arkasındaysa) uygulama onu listeleyemez; bu bir yazılım sınırı değil, bağlantı türü meselesidir.

## Sonraki aşama: donanım profili

Gerçek model etiketi, işlemci ve protokol belgeleri elinizde olduğunda:

1. `DeviceProtocol` arayüzünü uygulayan bir sınıf yazın (`isVerified`, `capabilities`, `verifiedFirmwareFormats`).
2. Bir `HardwareProfile` (VID/PID, `verifiedByDocumentation = true`) tanımlayın.
3. İkisini `ProtocolRegistry`'ye kaydedin.
4. Yazma için ayrı bir modül ekleyin; yedekleme (`BACKUP_FIRMWARE`) olmadan `WriteGate` yazmaya izin vermez.

Belge olmadan bu adımlar atılmamalıdır.
