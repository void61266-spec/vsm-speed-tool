package tr.vsm.speedtool.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tr.vsm.speedtool.data.LogLevel
import tr.vsm.speedtool.diagnostics.ConnectionTester
import tr.vsm.speedtool.diagnostics.TestOutcome
import tr.vsm.speedtool.ui.ActionButton
import tr.vsm.speedtool.ui.InfoRow
import tr.vsm.speedtool.ui.MainViewModel
import tr.vsm.speedtool.ui.SectionCard
import tr.vsm.speedtool.ui.StatusChip
import tr.vsm.speedtool.ui.Tone
import tr.vsm.speedtool.ui.UNKNOWN
import tr.vsm.speedtool.ui.screenPadding
import tr.vsm.speedtool.ui.theme.VsmColors
import tr.vsm.speedtool.usb.ConnectionPhase
import tr.vsm.speedtool.usb.idLabel
import tr.vsm.speedtool.usb.usbClassName

@Composable
fun DiagnosticsScreen(vm: MainViewModel, padding: PaddingValues) {
    val devices by vm.usb.devices.collectAsStateWithLifecycle()
    val session by vm.usb.session.collectAsStateWithLifecycle()
    val testRan by vm.testRan.collectAsStateWithLifecycle()
    val logs by vm.log.entries.collectAsStateWithLifecycle()

    val selected = devices.firstOrNull { it.key == session.selectedKey }
    val results = ConnectionTester.evaluate(testRan, vm.usb.supportsHost, devices, session)
    val lastError = session.lastError
        ?: logs.lastOrNull { it.level == LogLevel.ERROR }?.message
        ?: "Yok"

    val summary = when {
        !testRan -> "Test edilmedi"
        selected == null -> "USB cihazı seçilmedi"
        session.phase != ConnectionPhase.OPEN -> "USB düzeyinde sınırlı bilgi var; bağlantı kapalı"
        else -> "USB düzeyinde tanımlama yapıldı. Protokol bilinmediği için donanım teşhisi yapılamadı."
    }

    LazyColumn(
        contentPadding = screenPadding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionCard("Donanım teşhisi") {
                InfoRow("Donanım kimliği", selected?.idLabel() ?: UNKNOWN)
                InfoRow("USB bağlantı türü", if (vm.usb.supportsHost) "USB Host (OTG)" else "Host desteği yok")
                InfoRow(
                    "Desteklenen USB arayüzleri",
                    selected?.interfaces?.map { usbClassName(it.usbClass) }?.distinct()?.joinToString(", ")
                        ?.ifEmpty { UNKNOWN } ?: UNKNOWN
                )
                InfoRow("Haberleşme protokolü", UNKNOWN)
                InfoRow("Kontrol ünitesi işlemcisi", UNKNOWN)
                InfoRow("Bootloader durumu", UNKNOWN)
                InfoRow("Firmware sürümü", UNKNOWN)
                InfoRow("Son hata", lastError, if (lastError == "Yok") Color.Unspecified else VsmColors.Red)
                InfoRow("Teşhis sonucu", summary)
            }
        }

        item {
            SectionCard("Bağlantı testi") {
                Text(
                    "Sonuçlar telefonun gerçek USB durumundan hesaplanır. Çalıştırılmamış veya doğrulanamayan adımlar açıkça belirtilir.",
                    color = VsmColors.Muted
                )
                ActionButton("Bağlantı testini çalıştır", onClick = vm::runConnectionTest, primary = true)
                results.forEach { item ->
                    val tone = when (item.outcome) {
                        TestOutcome.NOT_TESTED -> Tone.NEUTRAL
                        TestOutcome.PASSED -> Tone.OK
                        TestOutcome.FAILED -> Tone.BAD
                        TestOutcome.UNVERIFIED -> Tone.WARN
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(item.title, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                        StatusChip(item.outcome.label, tone)
                        Text(item.detail, color = VsmColors.Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
