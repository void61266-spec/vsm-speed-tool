package tr.vsm.speedtool.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object VsmColors {
    val Background = Color(0xFF07090C)
    val Surface = Color(0xFF11161D)
    val SurfaceHigh = Color(0xFF171D26)
    val Outline = Color(0xFF232B36)
    val Blue = Color(0xFF2AA8FF)
    val Amber = Color(0xFFFFB020)
    val Red = Color(0xFFFF5468)
    val Green = Color(0xFF3DDC97)
    val Muted = Color(0xFF8A97A8)
    val Text = Color(0xFFE8EEF6)
}

private val scheme = darkColorScheme(
    primary = VsmColors.Blue,
    onPrimary = Color(0xFF03111C),
    background = VsmColors.Background,
    onBackground = VsmColors.Text,
    surface = VsmColors.Surface,
    onSurface = VsmColors.Text,
    surfaceVariant = VsmColors.SurfaceHigh,
    onSurfaceVariant = VsmColors.Muted,
    outline = VsmColors.Outline,
    error = VsmColors.Red
)

@Composable
fun VsmTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
