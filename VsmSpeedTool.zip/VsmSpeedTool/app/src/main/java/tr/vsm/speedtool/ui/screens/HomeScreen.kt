package tr.vsm.speedtool.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import tr.vsm.speedtool.data.LogLevel
import tr.vsm.speedtool.ui.InfoRow
import tr.vsm.speedtool.ui.MainViewModel
import tr.vsm.speedtool.ui.SectionCard
import tr.vsm.speedtool.ui.SpeedGauge
import tr.vsm.speedtool.ui.StatusChip
import tr.vsm.speedtool.ui.Tone
import tr.vsm.speedtool.ui.UNKNOWN
import tr.vsm.speedtool.ui.formatTime
import tr.vsm.speedtool.ui.screenPadding
import tr.vsm.speedtool.ui.toneColor
import tr.vsm.speedtool.ui.theme.VsmColors
import tr.vsm.speedtool.usb.ConnectionPhase
import tr.vsm.speedtool.usb.displayName
import kotlin.random.Random

@Composable
fun HomeScreen(vm: MainViewModel, padding: PaddingValues) {
    val session by vm.usb.session.collectAsStateWithLifecycle()
    val devices by vm.usb.devices.collectAsStateWithLifecycle()
    val logs by vm.log.entries.collectAsStateWithLifecycle()
    val simulation by vm.simulation.collectAsStateWithLifecycle()

    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(simulation) {
        if (simulation) {
            while (true) {
                target = Random.nextInt(0, 33).toFloat()
                delay(1800)
            }
        } else {
            target = 0f
        }
    }
    val shown by animateFloatAsState(targetValue = target, animationSpec = tween(900), label = "hiz")

    val selected = devices.firstOrNull { it.key == session.selectedKey }
    val deviceText = when {
        selected != null -> selected.displayName()
        devices.isNotEmpty() -> "${devices.size} cihaz listelendi, seçilmedi"
        else -> "Yok"
    }
    val connectionTone = when (session.phase) {
        ConnectionPhase.OPEN -> Tone.INFO
        ConnectionPhase.ERROR, ConnectionPhase.PERMISSION_DENIED -> Tone.BAD
        ConnectionPhase.IDLE -> Tone.NEUTRAL
        else -> Tone.WARN
    }

    LazyColumn(
        contentPadding = screenPadding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionCard("Hız") {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    SpeedGauge(speed = shown, simulated = simulation)
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    if (simulation) StatusChip("SİMÜLASYON", Tone.WARN) else StatusChip("CANLI VERİ YOK", Tone.NEUTRAL)
                }
                Text(
                    text = if (simulation) "Değerler araçtan gelmiyor; yalnızca arayüz denemesi içindir."
                    else "Araçtan gerçek hız verisi alınmadığı için 0 gösteriliyor.",
                    color = VsmColors.Muted,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        item {
            SectionCard("Araç ve bağlantı") {
                InfoRow("Araç", "Volta VSM 2026")
                InfoRow("Bağlantı durumu", session.phase.label, toneColor(connectionTone))
                InfoRow("Algılanan USB cihazı", deviceText)
                InfoRow("Firmware sürümü", UNKNOWN)
                InfoRow("Kontrol ünitesi modeli", UNKNOWN)
                InfoRow("Haberleşme protokolü", UNKNOWN)
                InfoRow("Son işlem zamanı", logs.lastOrNull()?.let { formatTime(it.timeMillis) } ?: "Yok")
                InfoRow(
                    "Hata sayacı",
                    logs.count { it.level == LogLevel.ERROR }.toString()
                )
                InfoRow("Çalışma modu", "Salt okunur teşhis", VsmColors.Green)
            }
        }
    }
}
