package tr.vsm.speedtool.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executors

enum class LogLevel(val label: String) {
    INFO("BİLGİ"),
    WARN("UYARI"),
    ERROR("HATA")
}

enum class LogCategory(val label: String) {
    APP("Uygulama"),
    USB("USB"),
    FIRMWARE("Firmware"),
    TEST("Test"),
    EXPORT("Dışa aktarım")
}

data class LogEntry(
    val timeMillis: Long,
    val level: LogLevel,
    val category: LogCategory,
    val message: String
)

class AppLog(private val file: File) {
    private val maxEntries = 500
    private val writer = CoroutineScope(SupervisorJob() + Executors.newSingleThreadExecutor().asCoroutineDispatcher())
    private val _entries = MutableStateFlow(load())
    val entries: StateFlow<List<LogEntry>> = _entries.asStateFlow()

    fun info(category: LogCategory, message: String) = add(LogLevel.INFO, category, message)
    fun warn(category: LogCategory, message: String) = add(LogLevel.WARN, category, message)
    fun error(category: LogCategory, message: String) = add(LogLevel.ERROR, category, message)

    fun add(level: LogLevel, category: LogCategory, message: String) {
        val clean = message.replace('\n', ' ').replace('\t', ' ')
        val entry = LogEntry(System.currentTimeMillis(), level, category, clean)
        _entries.update { (it + entry).takeLast(maxEntries) }
        val snapshot = _entries.value
        writer.launch { persist(snapshot) }
    }

    fun clear() {
        _entries.value = emptyList()
        writer.launch { runCatching { file.delete() } }
    }

    private fun persist(snapshot: List<LogEntry>) {
        runCatching {
            file.writeText(
                snapshot.joinToString("\n") {
                    "${it.timeMillis}\t${it.level.name}\t${it.category.name}\t${it.message}"
                }
            )
        }
    }

    private fun load(): List<LogEntry> {
        if (!file.exists()) return emptyList()
        return runCatching {
            file.readLines().mapNotNull { line ->
                val parts = line.split("\t", limit = 4)
                if (parts.size < 4) return@mapNotNull null
                LogEntry(
                    timeMillis = parts[0].toLong(),
                    level = LogLevel.valueOf(parts[1]),
                    category = LogCategory.valueOf(parts[2]),
                    message = parts[3]
                )
            }.takeLast(maxEntries)
        }.getOrDefault(emptyList())
    }
}
