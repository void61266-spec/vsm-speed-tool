package tr.vsm.speedtool.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tr.vsm.speedtool.ui.ActionButton
import tr.vsm.speedtool.ui.Banner
import tr.vsm.speedtool.ui.InfoRow
import tr.vsm.speedtool.ui.MainViewModel
import tr.vsm.speedtool.ui.SectionCard
import tr.vsm.speedtool.ui.StatusChip
import tr.vsm.speedtool.ui.Tone
import tr.vsm.speedtool.ui.UNKNOWN
import tr.vsm.speedtool.ui.screenPadding
import tr.vsm.speedtool.ui.theme.VsmColors
import tr.vsm.speedtool.usb.ConnectionPhase
import tr.vsm.speedtool.usb.UsbDeviceSnapshot
import tr.vsm.speedtool.usb.displayName
import tr.vsm.speedtool.usb.hex2
import tr.vsm.speedtool.usb.hex4
import tr.vsm.speedtool.usb.usbClassName

@Composable
fun UsbScreen(vm: MainViewModel, padding: PaddingValues) {
    val devices by vm.usb.devices.collectAsStateWithLifecycle()
    val session by vm.usb.session.collectAsStateWithLifecycle()
    val selected = devices.firstOrNull { it.key == session.selectedKey }

    LazyColumn(
        contentPadding = screenPadding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!vm.usb.supportsHost) {
            item {
                Banner(
                    Tone.BAD,
                    "USB Host desteği yok",
                    "Bu telefon USB Host (OTG) özelliğini bildirmiyor. Gerçek USB cihazları listelenemez."
                )
            }
        }

        item {
            SectionCard("USB cihazları") {
                Text(
                    "OTG adaptörünü takın, ardından listeyi yenileyin. Bu ekran yalnızca tanımlayıcı bilgileri okur; cihaza veri yazmaz.",
                    color = VsmColors.Muted
                )
                ActionButton("USB cihazlarını yenile", onClick = vm::refreshUsb, primary = true)
            }
        }

        if (devices.isEmpty()) {
            item {
                Banner(
                    Tone.INFO,
                    "Cihaz listelenmedi",
                    "Adaptörü ve kabloyu kontrol edin. Cihaz takılı olduğu halde görünmüyorsa Android onu USB Host cihazı olarak listelemiyor olabilir."
                )
            }
        }

        items(devices, key = { it.key }) { device ->
            DeviceCard(
                device = device,
                isSelected = device.key == session.selectedKey,
                onSelect = { vm.selectDevice(device.key) }
            )
        }

        if (selected != null) {
            item {
                SectionCard("Seçili cihaz") {
                    InfoRow("Üretici", selected.manufacturer ?: UNKNOWN)
                    InfoRow("Ürün", selected.product ?: UNKNOWN)
                    InfoRow("Satıcı kimliği (VID)", hex4(selected.vendorId))
                    InfoRow("Ürün kimliği (PID)", hex4(selected.productId))
                    InfoRow(
                        "Seri no",
                        session.serialFromConnection ?: selected.serial ?: "Bilinmiyor (izin gerekir)"
                    )
                    InfoRow("Aygıt sınıfı", usbClassName(selected.deviceClass))
                    InfoRow("Aygıt sürümü", selected.version ?: UNKNOWN)
                    InfoRow(
                        "Android erişim izni",
                        if (selected.hasPermission) "Verildi" else "Yok",
                        if (selected.hasPermission) VsmColors.Green else VsmColors.Amber
                    )
                    InfoRow("Bağlantı durumu", session.phase.label)
                    if (session.descriptorBytes != null) {
                        InfoRow("Ham tanımlayıcı boyutu", "${session.descriptorBytes} bayt")
                    }
                    if (session.deviceDescriptorHex != null) {
                        InfoRow("Aygıt tanımlayıcısı", session.deviceDescriptorHex ?: UNKNOWN)
                    }
                    session.lastError?.let { InfoRow("Son hata", it, VsmColors.Red) }

                    ActionButton(
                        "USB izni iste",
                        onClick = vm::requestPermission,
                        enabled = session.phase != ConnectionPhase.PERMISSION_PENDING
                    )
                    ActionButton(
                        "Salt okunur bağlantıyı aç",
                        onClick = vm::openConnection,
                        enabled = selected.hasPermission && session.phase != ConnectionPhase.OPEN,
                        primary = true
                    )
                    ActionButton(
                        "Bağlantıyı kapat",
                        onClick = vm::closeConnection,
                        enabled = session.phase == ConnectionPhase.OPEN
                    )
                }
            }

            item {
                SectionCard("Arayüzler ve uç noktalar") {
                    if (selected.interfaces.isEmpty()) {
                        Text("Cihaz arayüz bildirmedi.", color = VsmColors.Muted)
                    }
                    selected.interfaces.forEach { itf ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                "Arayüz ${itf.id}${if (itf.alternate != 0) " (alt ${itf.alternate})" else ""} · ${usbClassName(itf.usbClass)}",
                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                            )
                            Text(
                                "Alt sınıf ${hex2(itf.subclass)} · protokol ${hex2(itf.protocol)}" +
                                    (itf.name?.let { " · $it" } ?: ""),
                                color = VsmColors.Muted,
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (itf.endpoints.isEmpty()) {
                                Text("Uç nokta yok.", color = VsmColors.Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            itf.endpoints.forEach { ep ->
                                Text(
                                    "${hex2(ep.address)} · ${ep.direction} · ${ep.type} · ${ep.maxPacketSize} bayt",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(start = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Banner(
                Tone.WARN,
                "Tanınan cihaz, bilinen protokol demek değildir",
                "VID/PID görünmesi kontrol ünitesinin protokolünün anlaşıldığı anlamına gelmez. Bu sürüm hiçbir cihaza komut veya veri göndermez."
            )
        }
    }
}

@Composable
private fun DeviceCard(device: UsbDeviceSnapshot, isSelected: Boolean, onSelect: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = VsmColors.Surface,
        border = BorderStroke(1.dp, if (isSelected) VsmColors.Blue else VsmColors.Outline)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(device.displayName(), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text(
                "${device.interfaces.size} arayüz · ${device.key}",
                color = VsmColors.Muted,
                style = MaterialTheme.typography.bodySmall
            )
            if (isSelected) {
                StatusChip("SEÇİLİ", Tone.INFO)
            } else {
                ActionButton("Bu cihazı seç", onClick = onSelect)
            }
        }
    }
}
