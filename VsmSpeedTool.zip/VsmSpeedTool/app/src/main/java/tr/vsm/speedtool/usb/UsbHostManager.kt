package tr.vsm.speedtool.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import tr.vsm.speedtool.data.AppLog
import tr.vsm.speedtool.data.LogCategory

class UsbHostManager(
    private val context: Context,
    private val log: AppLog
) {
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val lock = Any()
    private var connection: UsbDeviceConnection? = null
    private var registered = false

    val supportsHost: Boolean = context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    private val _devices = MutableStateFlow<List<UsbDeviceSnapshot>>(emptyList())
    val devices: StateFlow<List<UsbDeviceSnapshot>> = _devices.asStateFlow()

    private val _session = MutableStateFlow(UsbSession())
    val session: StateFlow<UsbSession> = _session.asStateFlow()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_PERMISSION -> onPermissionResult(intent)
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> onAttached(intent)
                UsbManager.ACTION_USB_DEVICE_DETACHED -> onDetached(intent)
            }
        }
    }

    fun start() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
        log.info(LogCategory.USB, "USB izleme başladı. USB Host desteği: ${if (supportsHost) "var" else "yok"}.")
        refresh()
    }

    fun stop() {
        closeConnection()
        if (registered) {
            runCatching { context.unregisterReceiver(receiver) }
            registered = false
        }
    }

    fun refresh() {
        val list = try {
            usbManager.deviceList.values.map { snapshotOf(it) }.sortedBy { it.key }
        } catch (e: Exception) {
            log.error(LogCategory.USB, "USB cihaz listesi alınamadı: ${e.message ?: e.javaClass.simpleName}")
            emptyList()
        }
        _devices.value = list
        log.info(LogCategory.USB, "USB cihaz listesi yenilendi: ${list.size} cihaz.")

        val selected = _session.value.selectedKey ?: return
        val current = list.firstOrNull { it.key == selected }
        if (current == null) {
            closeConnection()
            _session.value = UsbSession(lastError = "Seçili USB cihazı artık listede yok.")
        } else if (current.hasPermission) {
            _session.update {
                if (it.phase == ConnectionPhase.SELECTED_NO_PERMISSION || it.phase == ConnectionPhase.PERMISSION_PENDING) {
                    it.copy(phase = ConnectionPhase.PERMISSION_GRANTED)
                } else it
            }
        }
    }

    fun select(key: String?) {
        closeConnection()
        if (key == null) {
            _session.value = UsbSession()
            return
        }
        val granted = _devices.value.firstOrNull { it.key == key }?.hasPermission == true
        _session.value = UsbSession(
            selectedKey = key,
            phase = if (granted) ConnectionPhase.PERMISSION_GRANTED else ConnectionPhase.SELECTED_NO_PERMISSION
        )
        log.info(LogCategory.USB, "USB cihazı seçildi: $key")
    }

    fun requestPermission() {
        val key = _session.value.selectedKey ?: return
        val device = usbManager.deviceList[key]
        if (device == null) {
            fail("Seçili USB cihazı artık bağlı değil.")
            return
        }
        if (usbManager.hasPermission(device)) {
            _session.update { it.copy(phase = ConnectionPhase.PERMISSION_GRANTED, permissionRequested = true) }
            log.info(LogCategory.USB, "USB izni zaten verilmiş.")
            refresh()
            return
        }
        val intent = Intent(ACTION_PERMISSION).setPackage(context.packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
        val pending = PendingIntent.getBroadcast(context, 0, intent, flags)
        _session.update { it.copy(phase = ConnectionPhase.PERMISSION_PENDING, permissionRequested = true, lastError = null) }
        log.info(LogCategory.USB, "Android USB erişim izni istendi.")
        try {
            usbManager.requestPermission(device, pending)
        } catch (e: Exception) {
            fail("İzin isteği başlatılamadı: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    suspend fun openReadOnly() = withContext(Dispatchers.IO) {
        val key = _session.value.selectedKey
        if (key == null) {
            fail("Önce bir USB cihazı seçin.")
            return@withContext
        }
        val device = usbManager.deviceList[key]
        if (device == null) {
            fail("Seçili USB cihazı artık bağlı değil.")
            return@withContext
        }
        if (!usbManager.hasPermission(device)) {
            fail("USB erişim izni yok. Önce izin isteyin.")
            return@withContext
        }
        closeConnection()
        _session.update { it.copy(openAttempted = true, openSucceeded = null, lastError = null) }
        try {
            val conn = usbManager.openDevice(device)
            if (conn == null) {
                fail("Bağlantı açılamadı. Cihaz başka bir uygulama veya sürücü tarafından kullanılıyor olabilir.")
                return@withContext
            }
            synchronized(lock) { connection = conn }
            val raw = runCatching { conn.rawDescriptors }.getOrNull()
            val serial = runCatching { conn.serial }.getOrNull()
            _session.update {
                it.copy(
                    phase = ConnectionPhase.OPEN,
                    openSucceeded = true,
                    descriptorBytes = raw?.size,
                    deviceDescriptorHex = raw?.take(18)?.toByteArray()?.toHex(),
                    serialFromConnection = serial
                )
            }
            log.info(LogCategory.USB, "Salt okunur bağlantı açıldı. Tanımlayıcı boyutu: ${raw?.size ?: "okunamadı"} bayt. Cihaza veri yazılmadı.")
            refresh()
        } catch (e: SecurityException) {
            fail("Android bağlantı iznini reddetti: ${e.message ?: "ayrıntı yok"}")
        } catch (e: Exception) {
            fail("Bağlantı açılırken hata oluştu: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    fun closeConnection(reason: String? = null) {
        val conn = synchronized(lock) {
            val current = connection
            connection = null
            current
        }
        if (conn != null) {
            runCatching { conn.close() }
            log.info(LogCategory.USB, reason ?: "USB bağlantısı kapatıldı.")
        }
        _session.update {
            if (it.phase == ConnectionPhase.OPEN) it.copy(phase = ConnectionPhase.PERMISSION_GRANTED) else it
        }
    }

    private fun onPermissionResult(intent: Intent) {
        val device = intent.usbDevice()
        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
        val label = device?.let { "${hex4(it.vendorId)}:${hex4(it.productId)}" } ?: "bilinmeyen cihaz"
        val isSelected = device != null && _session.value.selectedKey == device.deviceName
        if (granted) {
            log.info(LogCategory.USB, "USB izni verildi: $label")
            if (isSelected) _session.update { it.copy(phase = ConnectionPhase.PERMISSION_GRANTED, lastError = null) }
        } else {
            log.warn(LogCategory.USB, "USB izni reddedildi: $label")
            if (isSelected) {
                _session.update { it.copy(phase = ConnectionPhase.PERMISSION_DENIED, lastError = "USB erişim izni reddedildi.") }
            }
        }
        refresh()
    }

    private fun onAttached(intent: Intent) {
        val device = intent.usbDevice()
        val label = device?.let { "${hex4(it.vendorId)}:${hex4(it.productId)}" } ?: "bilinmeyen cihaz"
        log.info(LogCategory.USB, "USB cihazı takıldı: $label")
        refresh()
    }

    private fun onDetached(intent: Intent) {
        val device = intent.usbDevice()
        val label = device?.let { "${hex4(it.vendorId)}:${hex4(it.productId)}" } ?: "bilinmeyen cihaz"
        log.warn(LogCategory.USB, "USB cihazı çıkarıldı: $label")
        if (device != null && _session.value.selectedKey == device.deviceName) {
            closeConnection("Seçili cihaz çıkarıldığı için bağlantı kapatıldı.")
            _session.value = UsbSession(lastError = "Seçili USB cihazı çıkarıldı. Bağlantı kapatıldı.")
        }
        refresh()
    }

    private fun fail(message: String) {
        log.error(LogCategory.USB, message)
        _session.update {
            it.copy(
                phase = ConnectionPhase.ERROR,
                openSucceeded = if (it.openAttempted) false else it.openSucceeded,
                lastError = message
            )
        }
    }

    private fun snapshotOf(device: UsbDevice): UsbDeviceSnapshot {
        val granted = runCatching { usbManager.hasPermission(device) }.getOrDefault(false)
        val interfaces = (0 until device.interfaceCount).map { index ->
            val itf = device.getInterface(index)
            InterfaceInfo(
                id = itf.id,
                alternate = itf.alternateSetting,
                usbClass = itf.interfaceClass,
                subclass = itf.interfaceSubclass,
                protocol = itf.interfaceProtocol,
                name = runCatching { itf.name }.getOrNull(),
                endpoints = (0 until itf.endpointCount).map { e ->
                    val ep = itf.getEndpoint(e)
                    EndpointInfo(
                        address = ep.address,
                        direction = if (ep.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT",
                        type = endpointTypeName(ep.type),
                        maxPacketSize = ep.maxPacketSize,
                        interval = ep.interval
                    )
                }
            )
        }
        return UsbDeviceSnapshot(
            key = device.deviceName,
            vendorId = device.vendorId,
            productId = device.productId,
            manufacturer = runCatching { device.manufacturerName }.getOrNull(),
            product = runCatching { device.productName }.getOrNull(),
            serial = if (granted) runCatching { device.serialNumber }.getOrNull() else null,
            deviceClass = device.deviceClass,
            deviceSubclass = device.deviceSubclass,
            deviceProtocol = device.deviceProtocol,
            version = runCatching { device.version }.getOrNull(),
            hasPermission = granted,
            interfaces = interfaces
        )
    }

    private fun endpointTypeName(type: Int): String = when (type) {
        UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "CONTROL"
        UsbConstants.USB_ENDPOINT_XFER_ISOC -> "ISOCHRONOUS"
        UsbConstants.USB_ENDPOINT_XFER_BULK -> "BULK"
        UsbConstants.USB_ENDPOINT_XFER_INT -> "INTERRUPT"
        else -> "BİLİNMİYOR"
    }

    private fun Intent.usbDevice(): UsbDevice? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private fun ByteArray.toHex(): String = joinToString(" ") { "%02X".format(it) }

    companion object {
        const val ACTION_PERMISSION = "tr.vsm.speedtool.USB_PERMISSION"
    }
}
