package tr.vsm.speedtool.diagnostics

import tr.vsm.speedtool.protocol.ProtocolCapability
import tr.vsm.speedtool.protocol.ProtocolRegistry
import tr.vsm.speedtool.usb.ConnectionPhase
import tr.vsm.speedtool.usb.UsbDeviceSnapshot
import tr.vsm.speedtool.usb.UsbSession

enum class TestOutcome(val label: String) {
    NOT_TESTED("Test edilmedi"),
    PASSED("Başarılı"),
    FAILED("Başarısız"),
    UNVERIFIED("Doğrulanamadı")
}

data class TestItem(val title: String, val outcome: TestOutcome, val detail: String)

object ConnectionTester {
    private val titles = listOf(
        "USB cihazı bulundu mu?",
        "Android erişim izni alındı mı?",
        "USB bağlantısı açılabildi mi?",
        "Desteklenen arayüz belirlendi mi?",
        "Protokol doğrulandı mı?",
        "Firmware yazma desteği doğrulandı mı?"
    )

    fun evaluate(
        ran: Boolean,
        supportsHost: Boolean,
        devices: List<UsbDeviceSnapshot>,
        session: UsbSession
    ): List<TestItem> {
        if (!ran) return titles.map { TestItem(it, TestOutcome.NOT_TESTED, "Test çalıştırılmadı.") }

        val selected = devices.firstOrNull { it.key == session.selectedKey }
        val profile = selected?.let { ProtocolRegistry.profileFor(it.vendorId, it.productId) }
        val protocol = profile?.let { ProtocolRegistry.protocolFor(it) }

        val found = when {
            !supportsHost -> TestItem(titles[0], TestOutcome.FAILED, "Telefon USB Host (OTG) desteği bildirmiyor.")
            devices.isEmpty() -> TestItem(titles[0], TestOutcome.FAILED, "Listelenen USB cihazı yok. OTG adaptörünü ve kabloyu kontrol edin.")
            else -> TestItem(titles[0], TestOutcome.PASSED, "${devices.size} USB cihazı listelendi.")
        }

        val permission = when {
            selected == null -> TestItem(titles[1], TestOutcome.NOT_TESTED, "Cihaz seçilmedi.")
            selected.hasPermission -> TestItem(titles[1], TestOutcome.PASSED, "Android USB erişim izni verilmiş.")
            session.phase == ConnectionPhase.PERMISSION_DENIED -> TestItem(titles[1], TestOutcome.FAILED, "İzin reddedildi.")
            else -> TestItem(titles[1], TestOutcome.NOT_TESTED, "İzin henüz istenmedi veya yanıtlanmadı.")
        }

        val opened = when {
            !session.openAttempted -> TestItem(titles[2], TestOutcome.NOT_TESTED, "Bağlantı açma denenmedi.")
            session.openSucceeded == true -> TestItem(titles[2], TestOutcome.PASSED, "Salt okunur bağlantı açılabildi.")
            session.openSucceeded == false -> TestItem(titles[2], TestOutcome.FAILED, session.lastError ?: "Bağlantı açılamadı.")
            else -> TestItem(titles[2], TestOutcome.NOT_TESTED, "Sonuç bekleniyor.")
        }

        val itf = when {
            selected == null -> TestItem(titles[3], TestOutcome.NOT_TESTED, "Cihaz seçilmedi.")
            selected.interfaces.isEmpty() -> TestItem(titles[3], TestOutcome.FAILED, "Cihaz arayüz bildirmedi.")
            profile != null && profile.verifiedByDocumentation ->
                TestItem(titles[3], TestOutcome.PASSED, "Cihaz doğrulanmış donanım profiliyle eşleşti.")
            else -> TestItem(
                titles[3], TestOutcome.UNVERIFIED,
                "${selected.interfaces.size} arayüz algılandı ancak doğrulanmış donanım profili olmadığı için desteklenen arayüz belirlenemez."
            )
        }

        val proto = when {
            selected == null -> TestItem(titles[4], TestOutcome.NOT_TESTED, "Cihaz seçilmedi.")
            protocol != null && protocol.isVerified -> TestItem(titles[4], TestOutcome.PASSED, "${protocol.displayName} modülü doğrulanmış.")
            else -> TestItem(titles[4], TestOutcome.UNVERIFIED, "Doğrulanmış iletişim protokolü modülü yok.")
        }

        val canWrite = protocol != null && protocol.isVerified &&
            ProtocolCapability.WRITE_FIRMWARE in protocol.capabilities &&
            ProtocolCapability.BACKUP_FIRMWARE in protocol.capabilities
        val write = when {
            selected == null -> TestItem(titles[5], TestOutcome.NOT_TESTED, "Cihaz seçilmedi.")
            canWrite -> TestItem(titles[5], TestOutcome.PASSED, "Protokol modülü yazma ve yedekleme bildiriyor.")
            else -> TestItem(titles[5], TestOutcome.UNVERIFIED, "Yazma ve yedekleme desteği doğrulanamadı. Yazma kapalı kalır.")
        }

        return listOf(found, permission, opened, itf, proto, write)
    }
}
