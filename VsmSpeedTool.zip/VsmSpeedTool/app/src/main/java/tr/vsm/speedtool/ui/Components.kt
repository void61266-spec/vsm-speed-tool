package tr.vsm.speedtool.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tr.vsm.speedtool.ui.theme.VsmColors

enum class Tone { NEUTRAL, INFO, OK, WARN, BAD }

fun toneColor(tone: Tone): Color = when (tone) {
    Tone.NEUTRAL -> VsmColors.Muted
    Tone.INFO -> VsmColors.Blue
    Tone.OK -> VsmColors.Green
    Tone.WARN -> VsmColors.Amber
    Tone.BAD -> VsmColors.Red
}

fun screenPadding(inner: PaddingValues): PaddingValues = PaddingValues(
    start = 16.dp,
    end = 16.dp,
    top = inner.calculateTopPadding() + 12.dp,
    bottom = inner.calculateBottomPadding() + 16.dp
)

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = VsmColors.Surface),
        border = BorderStroke(1.dp, VsmColors.Outline)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = VsmColors.Blue,
                modifier = Modifier.semantics { heading() }
            )
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {},
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = label,
            color = VsmColors.Muted,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(0.45f)
        )
        Text(
            text = value,
            color = valueColor,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.55f)
        )
    }
}

@Composable
fun StatusChip(text: String, tone: Tone = Tone.NEUTRAL, modifier: Modifier = Modifier) {
    val color = toneColor(tone)
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun Banner(tone: Tone, title: String, text: String) {
    val color = toneColor(tone)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = title, fontWeight = FontWeight.Bold, color = color)
            Text(text = text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun ActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    primary: Boolean = false,
    danger: Boolean = false
) {
    val sizing = modifier
        .fillMaxWidth()
        .heightIn(min = 56.dp)
    val shape = RoundedCornerShape(14.dp)
    when {
        primary -> Button(onClick = onClick, modifier = sizing, enabled = enabled, shape = shape) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
        danger -> OutlinedButton(
            onClick = onClick,
            modifier = sizing,
            enabled = enabled,
            shape = shape,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = VsmColors.Red),
            border = BorderStroke(1.dp, VsmColors.Red.copy(alpha = if (enabled) 0.5f else 0.2f))
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
        else -> OutlinedButton(
            onClick = onClick,
            modifier = sizing,
            enabled = enabled,
            shape = shape,
            border = BorderStroke(1.dp, VsmColors.Outline)
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SpeedGauge(speed: Float, simulated: Boolean, maxSpeed: Float = 60f) {
    val shown = speed.coerceIn(0f, maxSpeed)
    val description = "Hız göstergesi: ${shown.toInt()} kilometre bölü saat" +
        if (simulated) ", simülasyon değeri" else ", canlı veri yok"
    Box(
        modifier = Modifier
            .widthIn(max = 300.dp)
            .fillMaxWidth()
            .aspectRatio(1f)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(
                color = VsmColors.SurfaceHigh,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            if (shown > 0f) {
                drawArc(
                    color = if (simulated) VsmColors.Amber else VsmColors.Blue,
                    startAngle = 135f,
                    sweepAngle = 270f * (shown / maxSpeed),
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = shown.toInt().toString(),
                fontSize = 68.sp,
                fontWeight = FontWeight.ExtraBold,
                color = VsmColors.Text
            )
            Text(text = "km/sa", color = VsmColors.Muted, fontSize = 14.sp, letterSpacing = 2.sp)
        }
    }
}
