package tr.vsm.speedtool.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("vsm_prefs", Context.MODE_PRIVATE)
    private val _simulation = MutableStateFlow(prefs.getBoolean(KEY_SIMULATION, false))
    val simulation: StateFlow<Boolean> = _simulation.asStateFlow()

    fun setSimulation(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SIMULATION, enabled).apply()
        _simulation.value = enabled
    }

    fun clear() {
        prefs.edit().clear().apply()
        _simulation.value = false
    }

    private companion object {
        const val KEY_SIMULATION = "simulation"
    }
}
