package tr.vsm.speedtool.usb

enum class ConnectionPhase(val label: String) {
    IDLE("Bağlı değil"),
    SELECTED_NO_PERMISSION("Cihaz seçildi, izin yok"),
    PERMISSION_PENDING("İzin bekleniyor"),
    PERMISSION_DENIED("İzin reddedildi"),
    PERMISSION_GRANTED("İzin verildi, bağlantı kapalı"),
    OPEN("Bağlantı açık (salt okunur)"),
    ERROR("Hata")
}

data class EndpointInfo(
    val address: Int,
    val direction: String,
    val type: String,
    val maxPacketSize: Int,
    val interval: Int
)

data class InterfaceInfo(
    val id: Int,
    val alternate: Int,
    val usbClass: Int,
    val subclass: Int,
    val protocol: Int,
    val name: String?,
    val endpoints: List<EndpointInfo>
)

data class UsbDeviceSnapshot(
    val key: String,
    val vendorId: Int,
    val productId: Int,
    val manufacturer: String?,
    val product: String?,
    val serial: String?,
    val deviceClass: Int,
    val deviceSubclass: Int,
    val deviceProtocol: Int,
    val version: String?,
    val hasPermission: Boolean,
    val interfaces: List<InterfaceInfo>
)

data class UsbSession(
    val selectedKey: String? = null,
    val phase: ConnectionPhase = ConnectionPhase.IDLE,
    val permissionRequested: Boolean = false,
    val openAttempted: Boolean = false,
    val openSucceeded: Boolean? = null,
    val lastError: String? = null,
    val descriptorBytes: Int? = null,
    val deviceDescriptorHex: String? = null,
    val serialFromConnection: String? = null
)

fun hex2(value: Int): String = "0x%02X".format(value)

fun hex4(value: Int): String = "0x%04X".format(value)

fun usbClassName(usbClass: Int): String {
    val name = when (usbClass) {
        0x00 -> "Arayüzde tanımlı"
        0x01 -> "Ses"
        0x02 -> "İletişim (CDC)"
        0x03 -> "HID"
        0x08 -> "Depolama"
        0x09 -> "Hub"
        0x0A -> "CDC-Data"
        0xEF -> "Karma"
        0xFE -> "Uygulamaya özel"
        0xFF -> "Üreticiye özel"
        else -> "Tanımsız"
    }
    return "$name (${hex2(usbClass)})"
}

fun UsbDeviceSnapshot.idLabel(): String = "${hex4(vendorId)}:${hex4(productId)}"

fun UsbDeviceSnapshot.displayName(): String = "${product ?: "USB cihazı"} (${idLabel()})"
