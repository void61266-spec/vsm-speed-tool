package tr.vsm.speedtool.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tr.vsm.speedtool.ui.screens.DiagnosticsScreen
import tr.vsm.speedtool.ui.screens.FirmwareScreen
import tr.vsm.speedtool.ui.screens.HomeScreen
import tr.vsm.speedtool.ui.screens.LogScreen
import tr.vsm.speedtool.ui.screens.SettingsScreen
import tr.vsm.speedtool.ui.screens.UsbScreen
import tr.vsm.speedtool.ui.theme.VsmColors
import tr.vsm.speedtool.usb.ConnectionPhase

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Ana", Icons.Filled.Home),
    USB("USB", Icons.Filled.Search),
    DIAGNOSTICS("Teşhis", Icons.Filled.Build),
    FIRMWARE("Firmware", Icons.Filled.Lock),
    LOGS("Günlük", Icons.Filled.Info),
    SETTINGS("Ayarlar", Icons.Filled.Settings)
}

@Composable
fun VsmApp(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    val snackbar = remember { SnackbarHostState() }
    val session by vm.usb.session.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    Scaffold(
        containerColor = VsmColors.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VsmColors.Background)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("VSM SPEED TOOL", fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, fontSize = 16.sp)
                    Text("Volta VSM · 2026", color = VsmColors.Muted, fontSize = 12.sp)
                }
                val tone = when (session.phase) {
                    ConnectionPhase.OPEN -> Tone.INFO
                    ConnectionPhase.ERROR, ConnectionPhase.PERMISSION_DENIED -> Tone.BAD
                    ConnectionPhase.IDLE -> Tone.NEUTRAL
                    else -> Tone.WARN
                }
                StatusChip(session.phase.label, tone)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = VsmColors.Surface) {
                Tab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                        alwaysShowLabel = true,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VsmColors.Blue,
                            selectedTextColor = VsmColors.Blue,
                            indicatorColor = VsmColors.Blue.copy(alpha = 0.16f),
                            unselectedIconColor = VsmColors.Muted,
                            unselectedTextColor = VsmColors.Muted
                        )
                    )
                }
            }
        }
    ) { inner ->
        when (tab) {
            Tab.HOME -> HomeScreen(vm, inner)
            Tab.USB -> UsbScreen(vm, inner)
            Tab.DIAGNOSTICS -> DiagnosticsScreen(vm, inner)
            Tab.FIRMWARE -> FirmwareScreen(vm, inner)
            Tab.LOGS -> LogScreen(vm, inner)
            Tab.SETTINGS -> SettingsScreen(vm, inner)
        }
    }
}
