package tr.vsm.speedtool.export

import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import tr.vsm.speedtool.data.LogEntry
import tr.vsm.speedtool.protocol.ProtocolRegistry
import tr.vsm.speedtool.usb.UsbDeviceSnapshot
import tr.vsm.speedtool.usb.UsbSession
import tr.vsm.speedtool.usb.hex2
import tr.vsm.speedtool.usb.hex4
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DiagnosticExport {
    fun sensitiveFields(includeSerial: Boolean): List<String> = listOf(
        "Telefon üreticisi, modeli ve Android sürümü",
        "Listelenen USB cihazlarının VID/PID, üretici ve ürün adları",
        if (includeSerial) "USB seri numaraları (DAHİL EDİLDİ)" else "USB seri numaraları (gizlendi)",
        "Uygulama günlükleri (son 200 kayıt)"
    )

    fun build(
        appVersion: String,
        supportsHost: Boolean,
        devices: List<UsbDeviceSnapshot>,
        session: UsbSession,
        logs: List<LogEntry>,
        simulation: Boolean,
        includeSerial: Boolean
    ): String {
        val root = JSONObject()
        root.put(
            "uygulama",
            JSONObject()
                .put("ad", "VSM Speed Tool")
                .put("surum", appVersion)
                .put("mod", "salt_okunur_teshis")
                .put("simulasyon_acik", simulation)
        )
        root.put("olusturulma", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date()))
        root.put(
            "telefon",
            JSONObject()
                .put("uretici", Build.MANUFACTURER)
                .put("model", Build.MODEL)
                .put("android", Build.VERSION.RELEASE)
                .put("sdk", Build.VERSION.SDK_INT)
                .put("usb_host_destegi", supportsHost)
        )

        val deviceArray = JSONArray()
        devices.forEach { d ->
            val interfaces = JSONArray()
            d.interfaces.forEach { itf ->
                val endpoints = JSONArray()
                itf.endpoints.forEach { ep ->
                    endpoints.put(
                        JSONObject()
                            .put("adres", hex2(ep.address))
                            .put("yon", ep.direction)
                            .put("tur", ep.type)
                            .put("max_paket", ep.maxPacketSize)
                            .put("aralik", ep.interval)
                    )
                }
                interfaces.put(
                    JSONObject()
                        .put("id", itf.id)
                        .put("alternatif", itf.alternate)
                        .put("sinif", hex2(itf.usbClass))
                        .put("alt_sinif", hex2(itf.subclass))
                        .put("protokol", hex2(itf.protocol))
                        .put("ad", itf.name ?: JSONObject.NULL)
                        .put("uc_noktalar", endpoints)
                )
            }
            deviceArray.put(
                JSONObject()
                    .put("vid", hex4(d.vendorId))
                    .put("pid", hex4(d.productId))
                    .put("uretici", d.manufacturer ?: JSONObject.NULL)
                    .put("urun", d.product ?: JSONObject.NULL)
                    .put("seri_no", if (includeSerial) (d.serial ?: JSONObject.NULL) else "[gizlendi]")
                    .put("aygit_sinifi", hex2(d.deviceClass))
                    .put("izin_var", d.hasPermission)
                    .put("arayuzler", interfaces)
            )
        }
        root.put("usb_cihazlari", deviceArray)

        root.put(
            "oturum",
            JSONObject()
                .put("durum", session.phase.name)
                .put("izin_istendi", session.permissionRequested)
                .put("baglanti_denendi", session.openAttempted)
                .put("baglanti_basarili", session.openSucceeded ?: JSONObject.NULL)
                .put("son_hata", session.lastError ?: JSONObject.NULL)
        )

        root.put(
            "protokol_modulleri",
            JSONObject()
                .put("kayitli_protokol", ProtocolRegistry.protocols().size)
                .put("donanim_profili", ProtocolRegistry.profiles().size)
        )

        val logArray = JSONArray()
        logs.takeLast(200).forEach {
            logArray.put(
                JSONObject()
                    .put("zaman", it.timeMillis)
                    .put("seviye", it.level.name)
                    .put("kategori", it.category.name)
                    .put("mesaj", it.message)
            )
        }
        root.put("gunluk", logArray)

        return root.toString(2)
    }
}
