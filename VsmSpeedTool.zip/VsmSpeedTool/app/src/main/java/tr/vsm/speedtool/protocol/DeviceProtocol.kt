package tr.vsm.speedtool.protocol

import tr.vsm.speedtool.firmware.FirmwareEntry
import tr.vsm.speedtool.usb.UsbDeviceSnapshot

enum class ProtocolCapability {
    IDENTIFY,
    READ_FIRMWARE_VERSION,
    BACKUP_FIRMWARE,
    WRITE_FIRMWARE
}

interface DeviceProtocol {
    val id: String
    val displayName: String
    val isVerified: Boolean
    val capabilities: Set<ProtocolCapability>
    val verifiedFirmwareFormats: Set<String>
}

data class HardwareProfile(
    val id: String,
    val displayName: String,
    val vendorId: Int,
    val productId: Int,
    val protocolId: String,
    val verifiedByDocumentation: Boolean
)

object ProtocolRegistry {
    private val protocols = mutableListOf<DeviceProtocol>()
    private val profiles = mutableListOf<HardwareProfile>()

    fun protocols(): List<DeviceProtocol> = protocols.toList()

    fun profiles(): List<HardwareProfile> = profiles.toList()

    fun registerProtocol(protocol: DeviceProtocol) {
        protocols.removeAll { it.id == protocol.id }
        protocols.add(protocol)
    }

    fun registerProfile(profile: HardwareProfile) {
        profiles.removeAll { it.id == profile.id }
        profiles.add(profile)
    }

    fun profileFor(vendorId: Int, productId: Int): HardwareProfile? =
        profiles.firstOrNull { it.vendorId == vendorId && it.productId == productId }

    fun protocolFor(profile: HardwareProfile): DeviceProtocol? =
        protocols.firstOrNull { it.id == profile.protocolId }
}

data class WriteGateResult(val allowed: Boolean, val blockers: List<String>)

object WriteGate {
    fun evaluate(device: UsbDeviceSnapshot?, connectionOpen: Boolean, firmware: FirmwareEntry?): WriteGateResult {
        val blockers = mutableListOf<String>()

        if (device == null) blockers += "USB cihazı seçilmedi."
        else if (!connectionOpen) blockers += "USB bağlantısı açık değil."

        val profile = device?.let { ProtocolRegistry.profileFor(it.vendorId, it.productId) }
        if (device != null && (profile == null || !profile.verifiedByDocumentation)) {
            blockers += "Bu cihaz için belgeyle doğrulanmış donanım profili yok."
        }

        val protocol = profile?.let { ProtocolRegistry.protocolFor(it) }
        if (profile != null && (protocol == null || !protocol.isVerified)) {
            blockers += "Doğrulanmış iletişim protokolü modülü yok."
        }
        if (protocol != null) {
            if (ProtocolCapability.WRITE_FIRMWARE !in protocol.capabilities) {
                blockers += "Protokol modülü firmware yazmayı desteklemiyor."
            }
            if (ProtocolCapability.BACKUP_FIRMWARE !in protocol.capabilities) {
                blockers += "Orijinal firmware yedeklenemiyor; geri dönüş doğrulanamaz."
            }
        }

        if (firmware == null) blockers += "Firmware dosyası seçilmedi."
        else if (protocol == null || firmware.detectedFormat !in protocol.verifiedFirmwareFormats) {
            blockers += "Dosya biçimi doğrulanmış değil."
        }

        return WriteGateResult(allowed = blockers.isEmpty(), blockers = blockers)
    }
}
