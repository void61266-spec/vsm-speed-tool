package tr.vsm.speedtool.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tr.vsm.speedtool.data.LogCategory
import tr.vsm.speedtool.firmware.FirmwareEntry
import tr.vsm.speedtool.firmware.FirmwareFormatDetector
import tr.vsm.speedtool.protocol.WriteGate
import tr.vsm.speedtool.ui.ActionButton
import tr.vsm.speedtool.ui.Banner
import tr.vsm.speedtool.ui.InfoRow
import tr.vsm.speedtool.ui.MainViewModel
import tr.vsm.speedtool.ui.SectionCard
import tr.vsm.speedtool.ui.StatusChip
import tr.vsm.speedtool.ui.Tone
import tr.vsm.speedtool.ui.formatBytes
import tr.vsm.speedtool.ui.formatTime
import tr.vsm.speedtool.ui.screenPadding
import tr.vsm.speedtool.ui.theme.VsmColors
import tr.vsm.speedtool.usb.ConnectionPhase

@Composable
fun FirmwareScreen(vm: MainViewModel, padding: PaddingValues) {
    val entries by vm.firmware.entries.collectAsStateWithLifecycle()
    val selectedId by vm.selectedFirmwareId.collectAsStateWithLifecycle()
    val devices by vm.usb.devices.collectAsStateWithLifecycle()
    val session by vm.usb.session.collectAsStateWithLifecycle()
    val logs by vm.log.entries.collectAsStateWithLifecycle()

    var pendingDelete by remember { mutableStateOf<FirmwareEntry?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFirmware(uri)
    }

    val selectedEntry = entries.firstOrNull { it.id == selectedId }
    val device = devices.firstOrNull { it.key == session.selectedKey }
    val gate = WriteGate.evaluate(device, session.phase == ConnectionPhase.OPEN, selectedEntry)
    val firmwareLogs = logs.filter { it.category == LogCategory.FIRMWARE }.takeLast(10).reversed()

    pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Dosya silinsin mi?") },
            text = { Text("${entry.displayName} yerel depolamadan silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteFirmware(entry.id)
                    pendingDelete = null
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Vazgeç") } }
        )
    }

    LazyColumn(
        contentPadding = screenPadding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Banner(
                Tone.WARN,
                "Firmware yazma devre dışı",
                "Bu sürüm yalnızca dosyaları saklar ve inceler. Orijinal firmware yedeklenemediği için bir yazma işlemi geri alınamayabilir."
            )
        }

        item {
            SectionCard("Firmware dosyası") {
                InfoRow("Mevcut firmware", "Bilinmiyor")
                InfoRow("Yeni firmware", selectedEntry?.displayName ?: "Seçilmedi")
                InfoRow("Dosya biçimi", selectedEntry?.detectedFormat ?: "Bilinmiyor")
                InfoRow("Donanım uyumluluğu", "Doğrulanmadı", VsmColors.Amber)
                ActionButton(
                    "Firmware dosyası seç",
                    onClick = { picker.launch(arrayOf("*/*")) },
                    primary = true
                )
            }
        }

        item {
            SectionCard("Desteklenen dosya biçimleri") {
                InfoRow("Doğrulanmış firmware biçimi", "Yok", VsmColors.Amber)
                Text(
                    "Aşağıdaki biçimler yalnızca dosya kabı olarak tanınır: ${FirmwareFormatDetector.recognizedContainers.joinToString(", ")}. Tanınan biçim, dosyanın bu donanımla uyumlu olduğu anlamına gelmez.",
                    color = VsmColors.Muted
                )
            }
        }

        item {
            Text(
                "Saklanan dosyalar (${entries.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = VsmColors.Blue
            )
        }

        if (entries.isEmpty()) {
            item { Text("Henüz dosya eklenmedi.", color = VsmColors.Muted) }
        }

        items(entries.reversed(), key = { it.id }) { entry ->
            FirmwareCard(
                entry = entry,
                isSelected = entry.id == selectedId,
                onSelect = { vm.selectFirmware(entry.id) },
                onDelete = { pendingDelete = entry }
            )
        }

        item {
            SectionCard("Yazma kapısı") {
                if (gate.blockers.isEmpty()) {
                    Text("Kapı koşulları karşılanıyor, ancak yazma modülü bu sürümde yok.", color = VsmColors.Muted)
                } else {
                    gate.blockers.forEach { Text("• $it", color = VsmColors.Amber) }
                }
                ActionButton("Firmware yaz (bu sürümde yok)", onClick = {}, enabled = false, danger = true)
            }
        }

        item {
            Banner(
                Tone.INFO,
                "SHA-256 bir güvenlik veya uyumluluk kanıtı değildir",
                "Özet yalnızca dosyanın değişmediğini karşılaştırmak içindir. Dosyanın güvenli ya da bu araca uygun olduğunu göstermez."
            )
        }

        item {
            SectionCard("Firmware işlem kayıtları") {
                if (firmwareLogs.isEmpty()) Text("Kayıt yok.", color = VsmColors.Muted)
                firmwareLogs.forEach {
                    Column {
                        Text(formatTime(it.timeMillis), color = VsmColors.Muted, style = MaterialTheme.typography.bodySmall)
                        Text(it.message, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun FirmwareCard(entry: FirmwareEntry, isSelected: Boolean, onSelect: () -> Unit, onDelete: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = VsmColors.Surface,
        border = BorderStroke(1.dp, if (isSelected) VsmColors.Blue else VsmColors.Outline)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(entry.displayName, fontWeight = FontWeight.Bold)
            Text(
                "${formatBytes(entry.sizeBytes)} · ${entry.detectedFormat} · ${formatTime(entry.addedAtMillis)}",
                color = VsmColors.Muted,
                style = MaterialTheme.typography.bodySmall
            )
            Text("SHA-256", color = VsmColors.Muted, style = MaterialTheme.typography.labelSmall)
            SelectionContainer {
                Text(entry.sha256, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
            }
            if (isSelected) StatusChip("SEÇİLİ", Tone.INFO) else ActionButton("Seç", onClick = onSelect)
            ActionButton("Sil", onClick = onDelete, danger = true)
        }
    }
}
