package tr.vsm.speedtool.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tr.vsm.speedtool.data.LogCategory
import tr.vsm.speedtool.data.LogLevel
import tr.vsm.speedtool.export.DiagnosticExport
import tr.vsm.speedtool.protocol.ProtocolRegistry
import tr.vsm.speedtool.ui.ActionButton
import tr.vsm.speedtool.ui.InfoRow
import tr.vsm.speedtool.ui.MainViewModel
import tr.vsm.speedtool.ui.SectionCard
import tr.vsm.speedtool.ui.formatTime
import tr.vsm.speedtool.ui.screenPadding
import tr.vsm.speedtool.ui.theme.VsmColors

private enum class LogFilter(val label: String) {
    ALL("Hepsi"),
    USB("USB"),
    ERRORS("Hatalar"),
    FIRMWARE("Firmware")
}

@Composable
fun LogScreen(vm: MainViewModel, padding: PaddingValues) {
    val logs by vm.log.entries.collectAsStateWithLifecycle()
    val devices by vm.usb.devices.collectAsStateWithLifecycle()
    val session by vm.usb.session.collectAsStateWithLifecycle()

    var filter by remember { mutableStateOf(LogFilter.ALL) }
    var showExport by remember { mutableStateOf(false) }
    var includeSerial by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.writeExport(uri, includeSerial)
    }

    val visible = logs.reversed().filter {
        when (filter) {
            LogFilter.ALL -> true
            LogFilter.USB -> it.category == LogCategory.USB
            LogFilter.ERRORS -> it.level == LogLevel.ERROR
            LogFilter.FIRMWARE -> it.category == LogCategory.FIRMWARE
        }
    }.take(200)

    if (showExport) {
        val preview = remember(includeSerial, logs, devices, session) { vm.buildExportJson(includeSerial) }
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Dışa aktarılacak veriler") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Dosyada şu hassas bilgiler bulunabilir:", fontWeight = FontWeight.SemiBold)
                    DiagnosticExport.sensitiveFields(includeSerial).forEach { Text("• $it") }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Switch(checked = includeSerial, onCheckedChange = { includeSerial = it })
                        Text("Seri numaralarını dahil et")
                    }
                    Box(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                        Text(
                            text = if (preview.length > 2500) preview.take(2500) + "\n…" else preview,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showExport = false
                    launcher.launch("vsm-speed-tool-tani.json")
                }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("Vazgeç") } }
        )
    }

    LazyColumn(
        contentPadding = screenPadding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionCard("Geliştirici modu") {
                InfoRow("Kayıtlı protokol modülü", ProtocolRegistry.protocols().size.toString())
                InfoRow("Donanım profili", ProtocolRegistry.profiles().size.toString())
                InfoRow("Desteklenen cihaz profilleri", if (ProtocolRegistry.profiles().isEmpty()) "Yok" else ProtocolRegistry.profiles().joinToString { it.displayName })
                InfoRow("Volta VSM protokolü", "Tanımlı değil", VsmColors.Amber)
                Text(
                    "Gerçek protokol belgeleri eklendiğinde DeviceProtocol arayüzünü uygulayan bir modül ProtocolRegistry'ye kaydedilir. Sahte protokol bulunmaz.",
                    color = VsmColors.Muted
                )
                ActionButton("Tanı verisini JSON olarak dışa aktar", onClick = { showExport = true }, primary = true)
                ActionButton("Kayıtları temizle", onClick = vm::clearLogs, danger = true)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LogFilter.entries.forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) })
                }
            }
        }

        if (visible.isEmpty()) {
            item { Text("Kayıt yok.", color = VsmColors.Muted) }
        }

        items(visible) { entry ->
            val color = when (entry.level) {
                LogLevel.INFO -> VsmColors.Blue
                LogLevel.WARN -> VsmColors.Amber
                LogLevel.ERROR -> VsmColors.Red
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text(
                    "${formatTime(entry.timeMillis)} · ${entry.level.label} · ${entry.category.label}",
                    color = color,
                    style = MaterialTheme.typography.labelSmall
                )
                Text(entry.message, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
