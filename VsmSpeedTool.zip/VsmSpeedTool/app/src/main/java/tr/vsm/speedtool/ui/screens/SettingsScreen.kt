package tr.vsm.speedtool.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tr.vsm.speedtool.ui.ActionButton
import tr.vsm.speedtool.ui.InfoRow
import tr.vsm.speedtool.ui.MainViewModel
import tr.vsm.speedtool.ui.SectionCard
import tr.vsm.speedtool.ui.screenPadding
import tr.vsm.speedtool.ui.theme.VsmColors

@Composable
fun SettingsScreen(vm: MainViewModel, padding: PaddingValues) {
    val simulation by vm.simulation.collectAsStateWithLifecycle()
    var showAbout by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Hakkında") },
            text = {
                Text(
                    "VSM Speed Tool ${vm.appVersion}\n\n" +
                        "Volta VSM (2026) kontrol ünitesini incelemek için hazırlanmış salt okunur teşhis altyapısıdır.\n\n" +
                        "Donanım protokolü doğrulanmadığı için araca veri, hız değişikliği veya firmware gönderilmez. " +
                        "Uygulama internet izni istemez ve verileri cihaz dışına göndermez."
                )
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Tamam") } }
        )
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("Veriler temizlensin mi?") },
            text = {
                Text(
                    "Günlükler, saklanan firmware dosyaları ve tercihler silinecek. " +
                        "Android'in verdiği USB izinleri bu işlemle silinmez."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showClear = false
                    vm.clearAllData()
                }) { Text("Temizle") }
            },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("Vazgeç") } }
        )
    }

    LazyColumn(
        contentPadding = screenPadding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionCard("Genel") {
                InfoRow("Dil", "Türkçe")
                InfoRow("Tema", "Koyu")
                InfoRow("Çalışma modu", "Salt okunur teşhis", VsmColors.Green)
                InfoRow("Uygulama sürümü", vm.appVersion)
            }
        }

        item {
            SectionCard("Gösterge simülasyonu") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Simülasyonu aç")
                        Text(
                            "Yalnızca arayüzü denemek içindir. Açıkken gösterge SİMÜLASYON etiketi taşır; değerler araçtan gelmez.",
                            color = VsmColors.Muted
                        )
                    }
                    Switch(checked = simulation, onCheckedChange = vm::setSimulation)
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionButton("Hakkında", onClick = { showAbout = true })
                ActionButton("Verileri temizle", onClick = { showClear = true }, danger = true)
            }
        }
    }
}
