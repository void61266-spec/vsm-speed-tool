package tr.vsm.speedtool.firmware

data class FirmwareEntry(
    val id: String,
    val displayName: String,
    val sizeBytes: Long,
    val sha256: String,
    val addedAtMillis: Long,
    val detectedFormat: String
)

object FirmwareFormatDetector {
    const val UNKNOWN_FORMAT = "Ham ikili / bilinmeyen"

    val recognizedContainers = listOf(
        "Intel HEX",
        "Motorola S-record",
        "ELF",
        "DfuSe (DFU)",
        "ZIP arşivi",
        "GZIP",
        UNKNOWN_FORMAT
    )

    fun detect(head: ByteArray): String {
        if (head.size >= 4 &&
            head[0] == 0x7F.toByte() &&
            head[1] == 'E'.code.toByte() &&
            head[2] == 'L'.code.toByte() &&
            head[3] == 'F'.code.toByte()
        ) return "ELF"

        if (head.size >= 5 && String(head, 0, 5, Charsets.US_ASCII) == "DfuSe") return "DfuSe (DFU)"

        if (head.size >= 4 &&
            head[0] == 'P'.code.toByte() &&
            head[1] == 'K'.code.toByte() &&
            head[2] == 3.toByte() &&
            head[3] == 4.toByte()
        ) return "ZIP arşivi"

        if (head.size >= 2 && head[0] == 0x1F.toByte() && head[1] == 0x8B.toByte()) return "GZIP"

        val firstLine = String(head, Charsets.US_ASCII).lineSequence().firstOrNull().orEmpty().trim()
        if (Regex("^:[0-9A-Fa-f]{10,}$").matches(firstLine)) return "Intel HEX"
        if (Regex("^S[0-9][0-9A-Fa-f]{5,}$").matches(firstLine)) return "Motorola S-record"

        return UNKNOWN_FORMAT
    }
}
