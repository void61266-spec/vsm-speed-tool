package tr.vsm.speedtool.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import tr.vsm.speedtool.data.AppLog
import tr.vsm.speedtool.data.AppPrefs
import tr.vsm.speedtool.data.LogCategory
import tr.vsm.speedtool.export.DiagnosticExport
import tr.vsm.speedtool.firmware.FirmwareRepository
import tr.vsm.speedtool.usb.UsbHostManager
import java.io.File
import java.io.IOException

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val log = AppLog(File(application.filesDir, "app.log"))
    private val prefs = AppPrefs(application)
    val usb = UsbHostManager(application, log)
    val firmware = FirmwareRepository(application, log)

    val simulation: StateFlow<Boolean> = prefs.simulation

    val appVersion: String = runCatching {
        application.packageManager.getPackageInfo(application.packageName, 0).versionName
    }.getOrNull() ?: "Bilinmiyor"

    private val _testRan = MutableStateFlow(false)
    val testRan: StateFlow<Boolean> = _testRan.asStateFlow()

    private val _selectedFirmwareId = MutableStateFlow<String?>(null)
    val selectedFirmwareId: StateFlow<String?> = _selectedFirmwareId.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        log.info(LogCategory.APP, "Uygulama başlatıldı. Mod: salt okunur teşhis. Firmware yazma devre dışı.")
        usb.start()
    }

    fun refreshUsb() = usb.refresh()

    fun selectDevice(key: String?) = usb.select(key)

    fun requestPermission() = usb.requestPermission()

    fun openConnection() {
        viewModelScope.launch { usb.openReadOnly() }
    }

    fun closeConnection() = usb.closeConnection()

    fun runConnectionTest() {
        usb.refresh()
        _testRan.value = true
        log.info(LogCategory.TEST, "Bağlantı testi çalıştırıldı.")
    }

    fun setSimulation(enabled: Boolean) {
        prefs.setSimulation(enabled)
        log.info(LogCategory.APP, if (enabled) "Gösterge simülasyonu açıldı." else "Gösterge simülasyonu kapatıldı.")
    }

    fun importFirmware(uri: Uri) {
        viewModelScope.launch {
            firmware.importFile(uri)
                .onSuccess {
                    _selectedFirmwareId.value = it.id
                    _messages.tryEmit("Dosya eklendi: ${it.displayName}")
                }
                .onFailure { _messages.tryEmit(it.message ?: "Dosya eklenemedi.") }
        }
    }

    fun selectFirmware(id: String?) {
        _selectedFirmwareId.value = id
    }

    fun deleteFirmware(id: String) {
        viewModelScope.launch {
            firmware.delete(id)
            if (_selectedFirmwareId.value == id) _selectedFirmwareId.value = null
        }
    }

    fun buildExportJson(includeSerial: Boolean): String = DiagnosticExport.build(
        appVersion = appVersion,
        supportsHost = usb.supportsHost,
        devices = usb.devices.value,
        session = usb.session.value,
        logs = log.entries.value,
        simulation = simulation.value,
        includeSerial = includeSerial
    )

    fun writeExport(uri: Uri, includeSerial: Boolean) {
        val json = buildExportJson(includeSerial)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stream = getApplication<Application>().contentResolver.openOutputStream(uri)
                    ?: throw IOException("Dosya açılamadı.")
                stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                log.info(LogCategory.EXPORT, "Tanı verisi JSON olarak dışa aktarıldı. Seri numarası dahil: ${if (includeSerial) "evet" else "hayır"}.")
                _messages.tryEmit("Tanı dosyası kaydedildi.")
            } catch (e: Exception) {
                val message = e.message ?: e.javaClass.simpleName
                log.error(LogCategory.EXPORT, "Dışa aktarma başarısız: $message")
                _messages.tryEmit("Dışa aktarma başarısız: $message")
            }
        }
    }

    fun clearLogs() = log.clear()

    fun clearAllData() {
        viewModelScope.launch {
            usb.select(null)
            log.clear()
            prefs.clear()
            firmware.clearAll()
            _selectedFirmwareId.value = null
            _testRan.value = false
            _messages.tryEmit("Uygulama verileri temizlendi.")
        }
    }

    override fun onCleared() {
        usb.stop()
        super.onCleared()
    }
}
