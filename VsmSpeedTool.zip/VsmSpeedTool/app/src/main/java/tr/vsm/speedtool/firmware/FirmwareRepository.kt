package tr.vsm.speedtool.firmware

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import tr.vsm.speedtool.data.AppLog
import tr.vsm.speedtool.data.LogCategory
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

class FirmwareRepository(
    private val context: Context,
    private val log: AppLog
) {
    private val dir = File(context.filesDir, "firmware").apply { mkdirs() }
    private val indexFile = File(dir, "index.json")

    private val _entries = MutableStateFlow(loadIndex())
    val entries: StateFlow<List<FirmwareEntry>> = _entries.asStateFlow()

    suspend fun importFile(uri: Uri): Result<FirmwareEntry> = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val target = File(dir, "$id.bin")
        try {
            val name = queryName(uri) ?: "firmware.bin"
            val digest = MessageDigest.getInstance("SHA-256")
            val head = ByteArrayOutputStream()
            var total = 0L

            val input = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Dosya açılamadı.")
            input.use { source ->
                target.outputStream().use { sink ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = source.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > MAX_BYTES) throw IOException("Dosya ${MAX_BYTES / (1024 * 1024)} MB sınırını aşıyor.")
                        if (head.size() < HEAD_BYTES) head.write(buffer, 0, minOf(read, HEAD_BYTES - head.size()))
                        digest.update(buffer, 0, read)
                        sink.write(buffer, 0, read)
                    }
                }
            }
            if (total == 0L) throw IOException("Dosya boş.")

            val entry = FirmwareEntry(
                id = id,
                displayName = name,
                sizeBytes = total,
                sha256 = digest.digest().joinToString("") { "%02x".format(it) },
                addedAtMillis = System.currentTimeMillis(),
                detectedFormat = FirmwareFormatDetector.detect(head.toByteArray())
            )
            _entries.value = _entries.value + entry
            saveIndex()
            log.info(LogCategory.FIRMWARE, "Firmware dosyası eklendi: $name, $total bayt, biçim: ${entry.detectedFormat}. Uyumluluk doğrulanmadı.")
            Result.success(entry)
        } catch (e: Exception) {
            runCatching { target.delete() }
            val message = e.message ?: "Dosya eklenemedi."
            log.error(LogCategory.FIRMWARE, "Firmware dosyası eklenemedi: $message")
            Result.failure(IOException(message))
        }
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        val entry = _entries.value.firstOrNull { it.id == id } ?: return@withContext
        runCatching { File(dir, "$id.bin").delete() }
        _entries.value = _entries.value.filterNot { it.id == id }
        saveIndex()
        log.info(LogCategory.FIRMWARE, "Firmware dosyası silindi: ${entry.displayName}")
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        dir.listFiles()?.forEach { runCatching { it.delete() } }
        _entries.value = emptyList()
    }

    private fun queryName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()

    private fun saveIndex() {
        val array = JSONArray()
        _entries.value.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.displayName)
                    .put("size", it.sizeBytes)
                    .put("sha256", it.sha256)
                    .put("added", it.addedAtMillis)
                    .put("format", it.detectedFormat)
            )
        }
        runCatching { indexFile.writeText(array.toString()) }
    }

    private fun loadIndex(): List<FirmwareEntry> {
        if (!indexFile.exists()) return emptyList()
        return try {
            val array = JSONArray(indexFile.readText())
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                FirmwareEntry(
                    id = o.getString("id"),
                    displayName = o.getString("name"),
                    sizeBytes = o.getLong("size"),
                    sha256 = o.getString("sha256"),
                    addedAtMillis = o.getLong("added"),
                    detectedFormat = o.getString("format")
                )
            }.filter { File(dir, "${it.id}.bin").exists() }
        } catch (e: Exception) {
            log.error(LogCategory.FIRMWARE, "Firmware dizini okunamadı: ${e.message ?: e.javaClass.simpleName}")
            emptyList()
        }
    }

    private companion object {
        const val MAX_BYTES = 64L * 1024 * 1024
        const val HEAD_BYTES = 512
    }
}
